package com.ing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngRunner {

    /**
     * This is the application class used by Sparing boot framework
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(IngRunner.class, args);
    }

}
